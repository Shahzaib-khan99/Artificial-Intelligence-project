# Customer Churn Prediction System
## Final Project | AI/ML Course | Option 1

---

## Project Overview

This project builds a complete **End-to-End Machine Learning Pipeline** to predict whether a telecom customer will churn (leave the service) based on their account details and usage patterns.

**Problem Type:** Binary Classification  
**Target Variable:** Churn (Yes / No)  
**Dataset:** Synthetic Telecom Customer Dataset (1,000 records, 14 features)  
**Models Used:** Logistic Regression + K-Nearest Neighbours (KNN)

---

## Project Structure

```
churn_project/
|-- churn_data.csv              <- Synthetic dataset (1,000 customers)
|-- churn_prediction.py         <- Standalone Python script (run directly)
|-- churn_prediction.ipynb      <- Full Jupyter Notebook (30 cells)
|-- evaluation_summary.csv      <- Model metric comparison table
|-- requirements.txt            <- Python package dependencies
|-- README.md                   <- This file
|-- plots/
    |-- fig1_churn_distribution.png
    |-- fig2_numeric_distributions.png
    |-- fig3_categorical_vs_churn.png
    |-- fig4_correlation_heatmap.png
    |-- fig5_knn_k_selection.png
    |-- fig6_confusion_matrices.png
    |-- fig7_roc_curves.png
    |-- fig8_metric_comparison.png
    |-- fig9_learning_curves.png
    |-- fig10_feature_importance.png
```

---

## How to Run

### Option A: Run the Python Script
```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the full pipeline
python churn_prediction.py
```

### Option B: Open the Jupyter Notebook
```bash
# 1. Install Jupyter if needed
pip install jupyter

# 2. Launch notebook
jupyter notebook churn_prediction.ipynb
```

### Option C: VS Code / Google Colab
- Upload `churn_prediction.ipynb` to Google Colab and run all cells
- Or open in VS Code with the Jupyter extension

---

## Dataset Features

| Feature | Type | Description |
|---------|------|-------------|
| CustomerID | ID | Unique identifier (dropped in ML) |
| Gender | Categorical | Male / Female |
| SeniorCitizen | Binary | 0 = No, 1 = Yes |
| Partner | Categorical | Has partner: Yes / No |
| Dependents | Categorical | Has dependents: Yes / No |
| Tenure | Numeric | Months with company (1-72) |
| PhoneService | Categorical | Yes / No |
| MultipleLines | Categorical | Yes / No / No phone service |
| InternetService | Categorical | DSL / Fiber optic / No |
| OnlineSecurity | Categorical | Yes / No / No internet service |
| Contract | Categorical | Month-to-month / One year / Two year |
| PaymentMethod | Categorical | 4 payment types |
| MonthlyCharges | Numeric | Monthly bill ($18-$118) |
| TotalCharges | Numeric | Total billed (2% missing values) |
| **Churn** | **Target** | **Yes / No** |

---

## ML Pipeline Steps

### Step 1: Data Generation and Loading
- 1,000 synthetic customer records with realistic distributions
- Intentional 2% missing values in TotalCharges
- ~34% churn rate (class imbalance present)

### Step 2: Exploratory Data Analysis (EDA)
- Churn distribution (count + pie chart)
- Numeric feature histograms by churn status
- Categorical feature bar charts vs. churn rate
- Correlation heatmap

### Step 3: Data Preprocessing
- Drop CustomerID (non-informative)
- Median imputation for missing TotalCharges
- Label Encoding for binary columns (Gender, Partner, etc.)
- One-Hot Encoding for multi-class columns (Contract, InternetService, etc.)
- 80/20 stratified train-test split
- StandardScaler (fit on train, applied to both sets)

### Step 4: Model Training
- **Logistic Regression** (C=1.0, max_iter=1000)
- **KNN** with optimal k selected via 5-fold cross-validation (k=1 to 20)

### Step 5: Evaluation Metrics
- Accuracy, Precision, Recall, F1-Score, ROC-AUC
- Confusion matrices for both models
- ROC curves comparison
- Side-by-side bar chart of all metrics

### Step 6: Overfitting / Underfitting Analysis
- Learning curves for both models
- Train vs. Validation F1-Score gap
- Bias-variance interpretation

### Step 7: Feature Importance
- Top 12 features by absolute Logistic Regression coefficient
- Business interpretation of top drivers

---

## Results

| Model | Accuracy | Precision | Recall | F1-Score | ROC-AUC |
|-------|----------|-----------|--------|----------|---------|
| Logistic Regression | 66.5% | 52.7% | 41.4% | 46.4% | 72.8% |
| KNN (k=11) | 65.0% | 50.0% | 48.6% | 49.3% | 69.1% |

### Best Model: Logistic Regression
- Higher ROC-AUC (72.8%) indicating better class discrimination
- More stable learning curve (Good Fit, train-val gap ~3%)
- Interpretable coefficients for business insights

---

## Key Business Insights

1. **Contract Type** is the most powerful predictor
   - Month-to-month: ~60% churn rate
   - Two-year contract: ~8% churn rate
   - Strategy: Offer incentives to upgrade to annual/two-year plans

2. **Fiber Optic Internet** customers churn more
   - Likely driven by higher monthly charges
   - Strategy: Check pricing competitiveness

3. **Electronic Check** users are higher-risk
   - Less automated/committed payment method
   - Strategy: Encourage auto-pay enrollment

4. **Short-tenure customers** (< 12 months) are the highest risk
   - Strategy: Implement onboarding loyalty programs in year 1

---

## Overfitting vs Underfitting

| Model | Train F1 | Val F1 | Gap | Verdict |
|-------|----------|--------|-----|---------|
| Logistic Regression | ~59% | ~56% | ~3% | Good Fit |
| KNN (k=11) | ~59% | ~51% | ~9% | Slight Overfitting |

**Logistic Regression** generalizes better due to its regularization (C parameter).  
**KNN** has slight overfitting because it memorizes training neighbors rather than learning a generalizable boundary.

---

## Requirements

```
numpy>=1.24
pandas>=1.5
scikit-learn>=1.2
matplotlib>=3.6
seaborn>=0.12
jupyter>=1.0
```

---

## Portfolio Statement

> Built a complete customer churn prediction ML pipeline including: synthetic dataset generation, 
> exploratory data analysis with 4 visualization types, missing value imputation, 
> Label and One-Hot encoding, feature scaling, Logistic Regression and KNN training 
> with optimal-k cross-validation, comprehensive evaluation using Accuracy/Precision/Recall/F1/ROC-AUC, 
> confusion matrices, ROC curves, learning curves for bias-variance analysis, 
> and feature importance visualization -- entirely from scratch in Python.

---

*Final Project | AI/ML Course | Option 1: End-to-End Customer Churn Prediction System*
