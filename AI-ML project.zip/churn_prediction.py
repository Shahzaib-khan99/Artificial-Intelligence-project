# ============================================================
#  Customer Churn Prediction System
#  Final Project  –  AI / ML Course
#  Option 1 : End-to-End Classification Pipeline
# ============================================================
#  Author  : AI/ML Student
#  Date    : 2025
#  Dataset : Synthetic Telecom Customer Churn (1 000 records)
# ============================================================

# ────────────────────────────────────────────────────────────
# 0.  IMPORTS
# ────────────────────────────────────────────────────────────
import os
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')                        # headless backend – no display needed
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection  import train_test_split, learning_curve, cross_val_score
from sklearn.preprocessing    import LabelEncoder, StandardScaler
from sklearn.linear_model     import LogisticRegression
from sklearn.neighbors        import KNeighborsClassifier
from sklearn.metrics          import (accuracy_score, precision_score,
                                      recall_score, f1_score,
                                      confusion_matrix, classification_report,
                                      roc_curve, auc)
from sklearn.impute            import SimpleImputer

warnings.filterwarnings('ignore')
np.random.seed(42)

PLOT_DIR = os.path.join(os.path.dirname(__file__), 'plots')
os.makedirs(PLOT_DIR, exist_ok=True)

# ────────────────────────────────────────────────────────────
# 1.  GENERATE SYNTHETIC TELECOM CHURN DATASET
# ────────────────────────────────────────────────────────────
def generate_churn_dataset(n: int = 1000) -> pd.DataFrame:
    """
    Produce a realistic synthetic telecom churn dataset.
    All feature distributions are calibrated to resemble
    the IBM Telco Customer Churn benchmark (~27 % churn rate).
    """
    rng = np.random.default_rng(42)

    # ── Demographics ────────────────────────────────────────
    gender         = rng.choice(['Male', 'Female'],         n)
    senior_citizen = rng.choice([0, 1],                     n, p=[0.84, 0.16])
    partner        = rng.choice(['Yes', 'No'],              n, p=[0.48, 0.52])
    dependents     = rng.choice(['Yes', 'No'],              n, p=[0.30, 0.70])

    # ── Service ─────────────────────────────────────────────
    tenure = np.clip(rng.exponential(30, n).astype(int) + 1, 1, 72)

    phone_service = rng.choice(['Yes', 'No'], n, p=[0.90, 0.10])
    multiple_lines = np.where(
        phone_service == 'No', 'No phone service',
        rng.choice(['Yes', 'No'], n)
    )

    internet_service = rng.choice(
        ['DSL', 'Fiber optic', 'No'], n, p=[0.34, 0.44, 0.22]
    )
    online_security = np.where(
        internet_service == 'No', 'No internet service',
        rng.choice(['Yes', 'No'], n, p=[0.29, 0.71])
    )

    contract = rng.choice(
        ['Month-to-month', 'One year', 'Two year'], n, p=[0.55, 0.21, 0.24]
    )
    payment_method = rng.choice(
        ['Electronic check', 'Mailed check',
         'Bank transfer (auto)', 'Credit card (auto)'],
        n, p=[0.34, 0.23, 0.22, 0.21]
    )

    # ── Financials ──────────────────────────────────────────
    monthly_charges = np.clip(
        rng.normal(65, 30, n)
        + np.where(internet_service == 'Fiber optic', 20, 0)
        + np.where(contract == 'Month-to-month', 10, -5),
        18, 118
    ).round(2)

    total_charges = np.clip(
        monthly_charges * tenure + rng.normal(0, 50, n),
        18, 8500
    ).round(2).astype(float)

    # ── Inject 2 % missing values in TotalCharges ───────────
    missing_idx = rng.choice(n, size=int(0.02 * n), replace=False)
    total_charges[missing_idx] = np.nan

    # ── Churn label (realistic ~27 % positive rate) ─────────
    churn_prob = np.clip(
        0.05
        + 0.35 * (contract == 'Month-to-month').astype(float)
        + 0.20 * (internet_service == 'Fiber optic').astype(float)
        + 0.15 * (payment_method == 'Electronic check').astype(float)
        - 0.15 * (tenure > 36).astype(float)
        + 0.10 * (senior_citizen == 1).astype(float)
        - 0.10 * (contract == 'Two year').astype(float)
        - 0.05 * (online_security == 'Yes').astype(float),
        0.01, 0.99
    )
    churn_raw = (rng.random(n) < churn_prob).astype(int)

    df = pd.DataFrame({
        'CustomerID':     [f'CUST_{i:04d}' for i in range(1, n + 1)],
        'Gender':          gender,
        'SeniorCitizen':   senior_citizen,
        'Partner':         partner,
        'Dependents':      dependents,
        'Tenure':          tenure,
        'PhoneService':    phone_service,
        'MultipleLines':   multiple_lines,
        'InternetService': internet_service,
        'OnlineSecurity':  online_security,
        'Contract':        contract,
        'PaymentMethod':   payment_method,
        'MonthlyCharges':  monthly_charges,
        'TotalCharges':    total_charges,
        'Churn':           np.where(churn_raw == 1, 'Yes', 'No')
    })
    return df


# ────────────────────────────────────────────────────────────
# 2.  LOAD DATASET
# ────────────────────────────────────────────────────────────
print("=" * 60)
print("  CUSTOMER CHURN PREDICTION – COMPLETE ML PIPELINE")
print("=" * 60)

csv_path = os.path.join(os.path.dirname(__file__), 'churn_data.csv')
df = generate_churn_dataset(1000)
df.to_csv(csv_path, index=False)
print(f"\n[1] Dataset generated and saved  →  churn_data.csv")
print(f"    Shape : {df.shape[0]} rows × {df.shape[1]} columns")


# ────────────────────────────────────────────────────────────
# 3.  EXPLORATORY DATA ANALYSIS  (EDA)
# ────────────────────────────────────────────────────────────
print("\n[2] EDA")
print("-" * 40)
print(df.head())
print("\nData Types:\n", df.dtypes)
print("\nStatistical Summary:\n", df.describe())

churn_counts = df['Churn'].value_counts()
churn_pct    = df['Churn'].value_counts(normalize=True) * 100
print(f"\nChurn Distribution:\n{churn_counts}")
print(f"\nChurn Rate: {churn_pct['Yes']:.1f}%  |  Retained: {churn_pct['No']:.1f}%")

# ── Plot 1 : Churn distribution ──────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle('Figure 1 – Churn Distribution Overview', fontsize=14, fontweight='bold')

colors = ['#2196F3', '#F44336']
axes[0].bar(churn_counts.index, churn_counts.values, color=colors, edgecolor='white', linewidth=1.5)
axes[0].set_title('Customer Churn Count', fontsize=12)
axes[0].set_xlabel('Churn Status');  axes[0].set_ylabel('Number of Customers')
for bar, val in zip(axes[0].patches, churn_counts.values):
    axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 8,
                 str(val), ha='center', fontsize=11, fontweight='bold')
axes[0].set_ylim(0, churn_counts.max() * 1.15)

wedges, texts, autotexts = axes[1].pie(
    churn_counts.values, labels=churn_counts.index,
    autopct='%1.1f%%', colors=colors, startangle=90,
    wedgeprops={'edgecolor': 'white', 'linewidth': 2}
)
axes[1].set_title('Churn Proportion', fontsize=12)
for at in autotexts: at.set_fontsize(12); at.set_fontweight('bold')

plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig1_churn_distribution.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig1_churn_distribution.png")

# ── Plot 2 : Numeric feature distributions ───────────────────
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
fig.suptitle('Figure 2 – Numerical Feature Distributions by Churn', fontsize=14, fontweight='bold')

num_cols = ['Tenure', 'MonthlyCharges', 'TotalCharges']
palette  = {'Yes': '#F44336', 'No': '#2196F3'}

for ax, col in zip(axes, num_cols):
    for label, grp in df.groupby('Churn'):
        ax.hist(grp[col].dropna(), bins=25, alpha=0.65,
                label=f'Churn={label}', color=palette[label], edgecolor='white')
    ax.set_title(col, fontsize=12)
    ax.set_xlabel(col);  ax.set_ylabel('Frequency')
    ax.legend()
    ax.grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig2_numeric_distributions.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig2_numeric_distributions.png")

# ── Plot 3 : Categorical feature vs. Churn ───────────────────
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
fig.suptitle('Figure 3 – Categorical Features vs. Churn Rate', fontsize=14, fontweight='bold')

cat_cols = ['Contract', 'InternetService', 'PaymentMethod',
            'Gender', 'SeniorCitizen', 'Partner']

for ax, col in zip(axes.flatten(), cat_cols):
    ct = pd.crosstab(df[col], df['Churn'], normalize='index') * 100
    ct[['No', 'Yes']].plot(kind='bar', ax=ax, color=['#2196F3', '#F44336'],
                           edgecolor='white', linewidth=1.2, width=0.7)
    ax.set_title(f'{col} vs Churn (%)', fontsize=11)
    ax.set_ylabel('Percentage (%)');  ax.set_xlabel('')
    ax.tick_params(axis='x', rotation=30)
    ax.legend(['No Churn', 'Churn'], fontsize=9)
    ax.grid(axis='y', alpha=0.3)
    ax.set_ylim(0, 115)

plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig3_categorical_vs_churn.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig3_categorical_vs_churn.png")

# ── Plot 4 : Correlation heatmap ─────────────────────────────
# Encode for correlation
df_enc = df.copy()
le_temp = LabelEncoder()
for c in df_enc.select_dtypes('object').columns:
    df_enc[c] = le_temp.fit_transform(df_enc[c].astype(str))
df_enc.drop('CustomerID', axis=1, inplace=True)
df_enc['TotalCharges'] = pd.to_numeric(df_enc['TotalCharges'], errors='coerce')

fig, ax = plt.subplots(figsize=(12, 9))
corr = df_enc.corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, mask=mask, annot=True, fmt='.2f', cmap='coolwarm',
            center=0, linewidths=0.5, ax=ax, annot_kws={'size': 8})
ax.set_title('Figure 4 – Feature Correlation Heatmap', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig4_correlation_heatmap.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig4_correlation_heatmap.png")


# ────────────────────────────────────────────────────────────
# 4.  DATA PREPROCESSING
# ────────────────────────────────────────────────────────────
print("\n[3] Preprocessing")
print("-" * 40)

df_proc = df.drop('CustomerID', axis=1).copy()
df_proc['TotalCharges'] = pd.to_numeric(df_proc['TotalCharges'], errors='coerce')

# ── 4a. Missing value check ──────────────────────────────────
print("Missing values before imputation:")
print(df_proc.isnull().sum()[df_proc.isnull().sum() > 0])

imputer = SimpleImputer(strategy='median')
df_proc['TotalCharges'] = imputer.fit_transform(df_proc[['TotalCharges']])
print("  → TotalCharges: median imputation applied")
print(f"  → Missing after imputation: {df_proc.isnull().sum().sum()}")

# ── 4b. Encode categorical features ─────────────────────────
#   Binary columns  → Label Encoding
binary_cols = ['Gender', 'Partner', 'Dependents',
               'PhoneService', 'Churn']
le = LabelEncoder()
for col in binary_cols:
    df_proc[col] = le.fit_transform(df_proc[col])

#   Multi-class columns → One-Hot Encoding
multi_cols = ['MultipleLines', 'InternetService', 'OnlineSecurity',
              'Contract', 'PaymentMethod']
df_proc = pd.get_dummies(df_proc, columns=multi_cols, drop_first=True)
print(f"  → Encoding done. Shape after encoding: {df_proc.shape}")

# ── 4c. Split features / target ──────────────────────────────
X = df_proc.drop('Churn', axis=1)
y = df_proc['Churn']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)
print(f"  → Train size : {X_train.shape[0]} | Test size : {X_test.shape[0]}")
print(f"  → Train churn rate : {y_train.mean()*100:.1f}%  |  Test churn rate : {y_test.mean()*100:.1f}%")

# ── 4d. Feature scaling ──────────────────────────────────────
scaler  = StandardScaler()
X_train = pd.DataFrame(scaler.fit_transform(X_train), columns=X.columns)
X_test  = pd.DataFrame(scaler.transform(X_test),      columns=X.columns)
print("  → StandardScaler applied (fit on train, transform on test)")


# ────────────────────────────────────────────────────────────
# 5.  MODEL TRAINING
# ────────────────────────────────────────────────────────────
print("\n[4] Model Training")
print("-" * 40)

# ── Logistic Regression ──────────────────────────────────────
lr_model = LogisticRegression(max_iter=1000, random_state=42, C=1.0)
lr_model.fit(X_train, y_train)
lr_pred  = lr_model.predict(X_test)
lr_prob  = lr_model.predict_proba(X_test)[:, 1]
print("  ✔ Logistic Regression trained")

# ── K-Nearest Neighbours (optimal K via cross-validation) ────
k_scores = {}
for k in range(1, 21):
    knn = KNeighborsClassifier(n_neighbors=k)
    cv_score = cross_val_score(knn, X_train, y_train, cv=5, scoring='f1').mean()
    k_scores[k] = cv_score

best_k = max(k_scores, key=k_scores.get)
knn_model = KNeighborsClassifier(n_neighbors=best_k)
knn_model.fit(X_train, y_train)
knn_pred  = knn_model.predict(X_test)
knn_prob  = knn_model.predict_proba(X_test)[:, 1]
print(f"  ✔ KNN trained  (best k = {best_k})")

# ── Plot 5 : K vs F1-score ───────────────────────────────────
fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(list(k_scores.keys()), list(k_scores.values()),
        marker='o', color='#2196F3', linewidth=2, markersize=7)
ax.axvline(best_k, color='#F44336', linestyle='--',
           label=f'Best k = {best_k}', linewidth=2)
ax.set_title(f'Figure 5 – KNN: Cross-Validation F1 per k  (Best k={best_k})',
             fontsize=13, fontweight='bold')
ax.set_xlabel('Number of Neighbours (k)')
ax.set_ylabel('CV F1-Score')
ax.legend(); ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig5_knn_k_selection.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig5_knn_k_selection.png")


# ────────────────────────────────────────────────────────────
# 6.  MODEL EVALUATION
# ────────────────────────────────────────────────────────────
print("\n[5] Evaluation")
print("-" * 40)

def get_metrics(y_true, y_pred, y_prob, name):
    """Return a dict of evaluation metrics."""
    return {
        'Model':     name,
        'Accuracy':  round(accuracy_score (y_true, y_pred) * 100, 2),
        'Precision': round(precision_score(y_true, y_pred) * 100, 2),
        'Recall':    round(recall_score   (y_true, y_pred) * 100, 2),
        'F1-Score':  round(f1_score       (y_true, y_pred) * 100, 2),
        'ROC-AUC':   round(auc(*roc_curve(y_true, y_prob)[:2]) * 100, 2),
    }

rows = [
    get_metrics(y_test, lr_pred,  lr_prob,  'Logistic Regression'),
    get_metrics(y_test, knn_pred, knn_prob, f'KNN (k={best_k})'),
]
results_df = pd.DataFrame(rows).set_index('Model')
print("\nEvaluation Summary Table (%):")
print(results_df.to_string())

results_csv = os.path.join(os.path.dirname(__file__), 'evaluation_summary.csv')
results_df.to_csv(results_csv)
print(f"\n  Saved: evaluation_summary.csv")

# ── Plot 6 : Confusion matrices ──────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle('Figure 6 – Confusion Matrices', fontsize=14, fontweight='bold')

for ax, pred, title in zip(axes,
                            [lr_pred, knn_pred],
                            ['Logistic Regression', f'KNN (k={best_k})']):
    cm = confusion_matrix(y_test, pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                xticklabels=['No Churn', 'Churn'],
                yticklabels=['No Churn', 'Churn'],
                linewidths=1.5, linecolor='white',
                annot_kws={'size': 14, 'weight': 'bold'})
    ax.set_title(title, fontsize=12)
    ax.set_xlabel('Predicted Label');  ax.set_ylabel('True Label')

plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig6_confusion_matrices.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig6_confusion_matrices.png")

# ── Plot 7 : ROC curves ──────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 6))
for prob, name, color in [
        (lr_prob,  'Logistic Regression', '#2196F3'),
        (knn_prob, f'KNN (k={best_k})',   '#F44336')]:
    fpr, tpr, _ = roc_curve(y_test, prob)
    roc_auc     = auc(fpr, tpr)
    ax.plot(fpr, tpr, color=color, lw=2,
            label=f'{name}  (AUC = {roc_auc:.3f})')

ax.plot([0, 1], [0, 1], 'k--', lw=1.5, label='Random Classifier')
ax.set_title('Figure 7 – ROC Curves', fontsize=13, fontweight='bold')
ax.set_xlabel('False Positive Rate'); ax.set_ylabel('True Positive Rate')
ax.legend(fontsize=11); ax.grid(alpha=0.3)
ax.set_xlim([0.0, 1.0]);  ax.set_ylim([0.0, 1.05])
plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig7_roc_curves.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig7_roc_curves.png")

# ── Plot 8 : Metric comparison bar chart ─────────────────────
fig, ax = plt.subplots(figsize=(10, 6))
metrics_cols = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC']
x  = np.arange(len(metrics_cols))
w  = 0.35
b1 = ax.bar(x - w/2, results_df.loc['Logistic Regression', metrics_cols],
            w, label='Logistic Regression', color='#2196F3',
            edgecolor='white', linewidth=1.2)
b2 = ax.bar(x + w/2, results_df.loc[f'KNN (k={best_k})', metrics_cols],
            w, label=f'KNN (k={best_k})', color='#F44336',
            edgecolor='white', linewidth=1.2)

for bar in list(b1) + list(b2):
    ax.text(bar.get_x() + bar.get_width()/2,
            bar.get_height() + 0.5,
            f'{bar.get_height():.1f}%',
            ha='center', va='bottom', fontsize=9, fontweight='bold')

ax.set_title('Figure 8 – Model Metric Comparison', fontsize=13, fontweight='bold')
ax.set_ylabel('Score (%)'); ax.set_ylim(40, 115)
ax.set_xticks(x); ax.set_xticklabels(metrics_cols, fontsize=11)
ax.legend(fontsize=11); ax.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig8_metric_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig8_metric_comparison.png")


# ────────────────────────────────────────────────────────────
# 7.  LEARNING CURVES  (Overfitting vs Underfitting)
# ────────────────────────────────────────────────────────────
print("\n[6] Overfitting / Underfitting Analysis")
print("-" * 40)

fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle('Figure 9 – Learning Curves (Bias–Variance Analysis)',
             fontsize=14, fontweight='bold')

for ax, model, title in zip(axes,
                             [lr_model, knn_model],
                             ['Logistic Regression',
                              f'KNN (k={best_k})']):
    sizes, tr_scores, cv_scores = learning_curve(
        model, X_train, y_train,
        cv=5, scoring='f1',
        train_sizes=np.linspace(0.1, 1.0, 10),
        n_jobs=-1
    )
    tr_mean = tr_scores.mean(axis=1) * 100
    cv_mean = cv_scores.mean(axis=1) * 100
    tr_std  = tr_scores.std(axis=1)  * 100
    cv_std  = cv_scores.std(axis=1)  * 100

    ax.plot(sizes, tr_mean, 'o-', color='#F44336',  lw=2, label='Training F1')
    ax.plot(sizes, cv_mean, 's-', color='#2196F3',  lw=2, label='Validation F1')
    ax.fill_between(sizes, tr_mean - tr_std, tr_mean + tr_std, alpha=0.12, color='#F44336')
    ax.fill_between(sizes, cv_mean - cv_std, cv_mean + cv_std, alpha=0.12, color='#2196F3')

    gap = tr_mean[-1] - cv_mean[-1]
    ax.set_title(f'{title}\n(Train–Val Gap = {gap:.1f}%)', fontsize=11)
    ax.set_xlabel('Training Samples')
    ax.set_ylabel('F1-Score (%)')
    ax.legend(fontsize=10); ax.grid(alpha=0.3)
    ax.set_ylim(0, 110)

    status = 'Overfitting' if gap > 10 else ('Good Fit' if gap < 5 else 'Slight Overfitting')
    print(f"  {title:>25s} | Train={tr_mean[-1]:.1f}% | Val={cv_mean[-1]:.1f}% | Gap={gap:.1f}% → {status}")

plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig9_learning_curves.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig9_learning_curves.png")


# ── Plot 10 : Feature importance (LR coefficients) ───────────
coef_df = pd.DataFrame({
    'Feature':     X.columns,
    'Coefficient': np.abs(lr_model.coef_[0])
}).sort_values('Coefficient', ascending=False).head(12)

fig, ax = plt.subplots(figsize=(10, 6))
bars = ax.barh(coef_df['Feature'][::-1], coef_df['Coefficient'][::-1],
               color='#2196F3', edgecolor='white', linewidth=1.2)
ax.set_title('Figure 10 – Top 12 Feature Importances\n(Logistic Regression |Coefficients|)',
             fontsize=13, fontweight='bold')
ax.set_xlabel('Absolute Coefficient Value')
ax.grid(axis='x', alpha=0.3)
plt.tight_layout()
plt.savefig(f'{PLOT_DIR}/fig10_feature_importance.png', dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: fig10_feature_importance.png")


# ────────────────────────────────────────────────────────────
# 8.  DETAILED CLASSIFICATION REPORT
# ────────────────────────────────────────────────────────────
print("\n[7] Detailed Classification Reports")
print("-" * 40)
print("\nLogistic Regression:")
print(classification_report(y_test, lr_pred, target_names=['No Churn', 'Churn']))
print(f"KNN (k={best_k}):")
print(classification_report(y_test, knn_pred, target_names=['No Churn', 'Churn']))

# ────────────────────────────────────────────────────────────
# 9.  SUMMARY
# ────────────────────────────────────────────────────────────
winner = results_df['F1-Score'].idxmax()
print("\n" + "=" * 60)
print("  PIPELINE COMPLETE")
print("=" * 60)
print(f"\n  Best Model  : {winner}")
print(f"  F1-Score    : {results_df.loc[winner, 'F1-Score']:.2f}%")
print(f"  Accuracy    : {results_df.loc[winner, 'Accuracy']:.2f}%")
print(f"  ROC-AUC     : {results_df.loc[winner, 'ROC-AUC']:.2f}%")
print("\n  Saved files:")
print("    ├── churn_data.csv")
print("    ├── evaluation_summary.csv")
print("    └── plots/  (10 figures)")
print("=" * 60)
